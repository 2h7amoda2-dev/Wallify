// Sample wallpapers data with Anime section
const wallpapers = [
    // Anime Wallpapers (20 items)
    { 
        id: 101,
        title: "ناروتو شيبودن",
        category: "anime",
        imageUrl: "https://wallpapercave.com/wp/wp4923981.jpg",
        color: "#FF7F11",
        likes: 124,
        rating: 4.5,
        liked: true
    },
    // ... (بقية البيانات كما هي في الملف الأصلي)
    // يمكنك نسخ بقية مصفوفة wallpapers من الملف الأصلي هنا
];

// DOM Elements
const wallpaperGrid = document.getElementById('wallpaperGrid');
const searchInput = document.getElementById('searchInput');
const loader = document.getElementById('loader');
const emptyState = document.getElementById('emptyState');
const modal = document.getElementById('modal');
const modalImg = document.getElementById('modalImg');
const modalTitle = document.getElementById('modalTitle');
const modalPrice = document.getElementById('modalPrice');
const modalClose = document.getElementById('modalClose');
const downloadBtn = document.getElementById('downloadBtn');
const setWallpaperBtn = document.getElementById('setWallpaperBtn');
const scrollTopBtn = document.getElementById('scrollTopBtn');
const darkModeToggle = document.getElementById('darkModeToggle');
const searchToggle = document.getElementById('searchToggle');
const searchContainer = document.getElementById('searchContainer');
const menuBtn = document.getElementById('menuBtn');
const sidebar = document.getElementById('sidebar');
const sidebarClose = document.getElementById('sidebarClose');
const sidebarOverlay = document.getElementById('sidebarOverlay');
const loginBtn = document.getElementById('loginBtn');
const proBtnSidebar = document.getElementById('proBtn');
const mainContainer = document.getElementById('mainContainer');
const categoriesContainer = document.getElementById('categoriesContainer');
const categoryBtns = document.querySelectorAll('.category-btn');
const authModal = document.getElementById('authModal');
const authClose = document.getElementById('authClose');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const showRegister = document.getElementById('showRegister');
const showLogin = document.getElementById('showLogin');
const loginTab = document.getElementById('loginTab');
const registerTab = document.getElementById('registerTab');
const loginFormContainer = document.getElementById('loginFormContainer');
const registerFormContainer = document.getElementById('registerFormContainer');
const proSubscriptionContainer = document.getElementById('proSubscriptionContainer');
const paymentFormContainer = document.getElementById('paymentFormContainer');
const subscribeBtn = document.getElementById('subscribeBtn');
const paymentForm = document.getElementById('paymentForm');
const userProfileSection = document.getElementById('userProfileSection');
const userAvatar = document.getElementById('userAvatar');
const userName = document.getElementById('userName');
const userEmail = document.getElementById('userEmail');
const userProBadge = document.getElementById('userProBadge');
const loginMenuItem = document.getElementById('loginMenuItem');
const logoutMenuItem = document.getElementById('logoutMenuItem');
const logoutBtn = document.getElementById('logoutBtn');

// State
let currentWallpaper = null;
let isDarkMode = localStorage.getItem('darkMode') === 'true';
let isSearchVisible = false;
let isSidebarOpen = false;
let currentCategory = 'all';
let currentUser = JSON.parse(localStorage.getItem('currentUser')) || {
    name: "حساب المطور",
    email: "2h7amoda2@gmail.com",
    isPro: true
};
let currentView = 'login'; // 'login', 'register', 'pro', 'payment'

// Initialize
function init() {
    renderWallpapers(wallpapers);
    setupEventListeners();
    applyDarkMode();
    checkAuthState();
}

// Check authentication state
function checkAuthState() {
    if (currentUser) {
        // User is logged in
        loginMenuItem.style.display = 'none';
        logoutMenuItem.style.display = 'block';
        userProfileSection.style.display = 'block';
        
        // Set user info
        userAvatar.textContent = currentUser.name.charAt(0).toUpperCase();
        userName.textContent = currentUser.name;
        userEmail.textContent = currentUser.email;
        
        // Show PRO badge if user has PRO
        if (currentUser.isPro) {
            userProBadge.style.display = 'inline-block';
        } else {
            userProBadge.style.display = 'none';
        }
    } else {
        // User is not logged in
        loginMenuItem.style.display = 'block';
        logoutMenuItem.style.display = 'none';
        userProfileSection.style.display = 'none';
    }
}

// Render wallpapers
function renderWallpapers(wallpapersToRender) {
    if (wallpapersToRender.length === 0) {
        emptyState.style.display = 'block';
        wallpaperGrid.style.display = 'none';
        return;
    }

    emptyState.style.display = 'none';
    wallpaperGrid.style.display = 'grid';
    wallpaperGrid.innerHTML = '';

    // Filter by category if not 'all'
    let filteredWallpapers = currentCategory === 'all' 
        ? wallpapersToRender 
        : wallpapersToRender.filter(w => w.category === currentCategory);

    // Hide premium wallpapers if user is not PRO
    if (!currentUser?.isPro) {
        filteredWallpapers = filteredWallpapers.filter(w => w.category !== 'premium');
    }

    filteredWallpapers.forEach((wallpaper, index) => {
        const wallpaperElement = document.createElement('div');
        wallpaperElement.className = 'wallpaper-item';
        wallpaperElement.style.animationDelay = `${index * 0.1}s`;
        
        // Add pro-feature class for premium wallpapers
        const isProWallpaper = wallpaper.category === 'premium';
        if (isProWallpaper) {
            wallpaperElement.classList.add('pro-feature');
        }
        
        // Render rating stars
        const ratingStars = [];
        const fullStars = Math.floor(wallpaper.rating);
        const hasHalfStar = wallpaper.rating % 1 >= 0.5;
        
        for (let i = 0; i < 5; i++) {
            if (i < fullStars) {
                ratingStars.push('<span class="rating-star">★</span>');
            } else if (i === fullStars && hasHalfStar) {
                ratingStars.push('<span class="rating-star">☆</span>');
            } else {
                ratingStars.push('<span class="rating-star">☆</span>');
            }
        }
        
        wallpaperElement.innerHTML = `
            <img src="${wallpaper.imageUrl}" 
                 class="wallpaper-img" 
                 alt="${wallpaper.title}"
                 loading="lazy"
                 onload="this.classList.add('loaded')">
            <div class="wallpaper-overlay">
                <div class="wallpaper-title">${wallpaper.title}</div>
                <div class="wallpaper-category">${wallpaper.category}${isProWallpaper ? ' (PRO)' : ''}</div>
                ${isProWallpaper ? `<div class="wallpaper-price">$${wallpaper.price}</div>` : ''}
                <div class="rating-container">
                    ${ratingStars.join('')}
                    <span style="margin-right: 5px; font-size: 11px;">(${wallpaper.rating.toFixed(1)})</span>
                </div>
            </div>
            <div class="wallpaper-actions">
                <button class="action-btn like-btn ${wallpaper.liked ? 'liked' : ''}" onclick="toggleLike(${wallpaper.id}, event)">
                    ♥
                </button>
                <button class="action-btn ${isProWallpaper ? 'pro-action-btn' : ''}" onclick="downloadWallpaper(${wallpaper.id}, event)">⬇</button>
                <button class="action-btn ${isProWallpaper ? 'pro-action-btn' : ''}" onclick="setAsWallpaper(${wallpaper.id}, event)">🖼️</button>
            </div>
        `;

        wallpaperElement.addEventListener('click', (e) => {
            // Don't open modal if clicking on action buttons
            if (e.target.closest('.wallpaper-actions')) {
                return;
            }
            
            if (isProWallpaper && !currentUser?.isPro) {
                showNotification('هذه الخلفية متاحة للمشتركين المميزين فقط', true);
                openProSubscription();
            } else {
                openModal(wallpaper);
            }
        });
        wallpaperGrid.appendChild(wallpaperElement);
    });
}

// Toggle like for wallpaper
function toggleLike(id, event) {
    if (event) event.stopPropagation();
    
    const wallpaper = wallpapers.find(w => w.id === id);
    if (!wallpaper) return;
    
    // Toggle like status
    wallpaper.liked = !wallpaper.liked;
    
    // Update like count
    if (wallpaper.liked) {
        wallpaper.likes++;
    } else {
        wallpaper.likes--;
    }
    
    // Update the UI
    const likeBtn = event.target.closest('.like-btn');
    if (likeBtn) {
        likeBtn.classList.toggle('liked');
    }
    
    // Show notification
    showNotification(wallpaper.liked ? 'تمت إضافة الإعجاب!' : 'تم إزالة الإعجاب');
}

// Open modal with wallpaper
function openModal(wallpaper) {
    currentWallpaper = wallpaper;
    modalImg.src = wallpaper.imageUrl;
    modalTitle.textContent = wallpaper.title;
    
    // Show price if it's a premium wallpaper
    if (wallpaper.category === 'premium') {
        modalPrice.textContent = `السعر: $${wallpaper.price}`;
        modalPrice.style.display = 'block';
    } else {
        modalPrice.style.display = 'none';
    }
    
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

// Close modal
function closeModal() {
    modal.classList.remove('active');
    document.body.style.overflow = 'auto';
}

// Open auth modal
function openAuthModal(view = 'login') {
    currentView = view;
    updateAuthView();
    authModal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

// Close auth modal
function closeAuthModal() {
    authModal.classList.remove('active');
    document.body.style.overflow = 'auto';
}

// Open PRO subscription view
function openProSubscription() {
    if (!currentUser) {
        openAuthModal('login');
        showNotification('الرجاء تسجيل الدخول أولاً للاشتراك في الخطة المميزة', true);
        return;
    }
    
    currentView = 'pro';
    updateAuthView();
    authModal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

// Open payment form
function openPaymentForm() {
    currentView = 'payment';
    updateAuthView();
}

// Update auth modal view
function updateAuthView() {
    // Update tabs
    loginTab.classList.remove('active');
    registerTab.classList.remove('active');
    
    // Hide all containers
    loginFormContainer.style.display = 'none';
    registerFormContainer.style.display = 'none';
    proSubscriptionContainer.style.display = 'none';
    paymentFormContainer.style.display = 'none';
    
    // Show the current view
    if (currentView === 'login') {
        loginTab.classList.add('active');
        loginFormContainer.style.display = 'block';
    } else if (currentView === 'register') {
        registerTab.classList.add('active');
        registerFormContainer.style.display = 'block';
    } else if (currentView === 'pro') {
        proSubscriptionContainer.style.display = 'block';
    } else if (currentView === 'payment') {
        proSubscriptionContainer.style.display = 'block';
        paymentFormContainer.style.display = 'block';
    }
}

// Toggle sidebar
function toggleSidebar() {
    isSidebarOpen = !isSidebarOpen;
    
    if (isSidebarOpen) {
        sidebar.classList.add('active');
        sidebarOverlay.classList.add('active');
        mainContainer.classList.add('sidebar-active');
        menuBtn.classList.add('active');
    } else {
        sidebar.classList.remove('active');
        sidebarOverlay.classList.remove('active');
        mainContainer.classList.remove('sidebar-active');
        menuBtn.classList.remove('active');
    }
}

// Set active category
function setActiveCategory(category) {
    if (category === 'premium' && !currentUser?.isPro) {
        showNotification('هذه الفئة متاحة للمشتركين المميزين فقط', true);
        openProSubscription();
        return;
    }
    
    currentCategory = category;
    categoryBtns.forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.category === category) {
            btn.classList.add('active');
        }
    });
    renderWallpapers(wallpapers);
}

// Download wallpaper
function downloadWallpaper(id, event) {
    if (event) event.stopPropagation();
    const wallpaper = wallpapers.find(w => w.id === id);
    if (!wallpaper) return;

    // Check if PRO is required
    if (wallpaper.category === 'premium' && !currentUser?.isPro) {
        showNotification('تحميل الخلفيات المميزة يتطلب اشتراك PRO', true);
        openProSubscription();
        return;
    }

    const link = document.createElement('a');
    link.href = wallpaper.imageUrl;
    link.download = `wallify-${wallpaper.title.replace(/\s+/g, '-')}-${id}.jpg`;
    link.click();

    showNotification('جاري تحميل الخلفية...');
}

// Set as wallpaper
function setAsWallpaper(id, event) {
    if (event) event.stopPropagation();
    const wallpaper = wallpapers.find(w => w.id === id);
    
    // Check if PRO is required
    if (wallpaper.category === 'premium' && !currentUser?.isPro) {
        showNotification('تعيين الخلفيات المميزة يتطلب اشتراك PRO', true);
        openProSubscription();
        return;
    }
    
    showNotification('هذه الميزة متاحة في تطبيق الهاتف فقط');
}

// Search wallpapers
function searchWallpapers(query) {
    const filtered = wallpapers.filter(wallpaper => 
        wallpaper.title.toLowerCase().includes(query.toLowerCase()) ||
        wallpaper.category.toLowerCase().includes(query.toLowerCase())
    );
    
    renderWallpapers(filtered);
}

// Show notification
function showNotification(message, isPro = false) {
    const notification = document.createElement('div');
    notification.className = `notification ${isPro ? 'pro-notification' : ''}`;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Toggle dark mode
function toggleDarkMode() {
    isDarkMode = !isDarkMode;
    localStorage.setItem('darkMode', isDarkMode);
    applyDarkMode();
}

// Apply dark mode
function applyDarkMode() {
    if (isDarkMode) {
        document.body.classList.add('dark-mode');
        darkModeToggle.textContent = '☀️';
    } else {
        document.body.classList.remove('dark-mode');
        darkModeToggle.textContent = '🌙';
    }
}

// Toggle search visibility
function toggleSearch() {
    isSearchVisible = !isSearchVisible;
    if (isSearchVisible) {
        searchContainer.style.display = 'block';
        searchInput.focus();
    } else {
        searchContainer.style.display = 'none';
        searchInput.value = '';
        searchWallpapers('');
    }
}

// Handle login
function handleLogin(email, password) {
    // In a real app, you would send this to your backend
    // For demo purposes, we'll just simulate a successful login
    
    // Simple validation
    if (!email || !password) {
        showNotification('الرجاء إدخال البريد الإلكتروني وكلمة المرور');
        return;
    }
    
    // Check if user exists in localStorage
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const user = users.find(u => u.email === email && u.password === password);
    
    if (!user) {
        showNotification('البريد الإلكتروني أو كلمة المرور غير صحيحة');
        return;
    }
    
    // Simulate API call
    setTimeout(() => {
        // Update current user
        currentUser = {
            name: user.name,
            email: user.email,
            isPro: user.isPro || false
        };
        
        // Save to localStorage
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        
        // Update UI
        checkAuthState();
        closeAuthModal();
        showNotification(`مرحباً ${user.name}! تم تسجيل الدخول بنجاح`);
        
        // Reset form
        loginForm.reset();
        
        // Reload wallpapers to show/hide premium content
        renderWallpapers(wallpapers);
    }, 1000);
}

// Handle registration
function handleRegister(name, email, password, confirmPassword) {
    // Validation
    if (!name || !email || !password || !confirmPassword) {
        showNotification('الرجاء ملء جميع الحقول');
        return;
    }
    
    if (password !== confirmPassword) {
        showNotification('كلمة المرور غير متطابقة');
        return;
    }
    
    if (password.length < 6) {
        showNotification('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
        return;
    }
    
    // Check if user already exists
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const userExists = users.some(u => u.email === email);
    
    if (userExists) {
        showNotification('هذا البريد الإلكتروني مسجل بالفعل');
        return;
    }
    
    // Simulate API call
    setTimeout(() => {
        // Create new user
        const newUser = {
            name: name,
            email: email,
            password: password,
            isPro: false
        };
        
        // Save to localStorage
        users.push(newUser);
        localStorage.setItem('users', JSON.stringify(users));
        
        // Log in the new user
        currentUser = newUser;
        localStorage.setItem('currentUser', JSON.stringify(newUser));
        
        // Update UI
        checkAuthState();
        showNotification(`مرحباً ${name}! تم إنشاء حسابك بنجاح`);
        
        // Switch to login view
        currentView = 'login';
        updateAuthView();
        
        // Reset form
        registerForm.reset();
        
        // Close modal after delay
        setTimeout(() => {
            closeAuthModal();
        }, 1500);
    }, 1000);
}

// Handle PRO subscription
function handleSubscribe() {
    if (!currentUser) {
        showNotification('الرجاء تسجيل الدخول أولاً');
        return;
    }
    
    // Show payment form
    openPaymentForm();
}

// Handle payment
function handlePayment(cardNumber, cardExpiry, cardCvc, cardName) {
    // Validate card details
    if (!cardNumber || !cardExpiry || !cardCvc || !cardName) {
        showNotification('الرجاء ملء جميع تفاصيل البطاقة');
        return;
    }
    
    if (!/^\d{16}$/.test(cardNumber.replace(/\s/g, ''))) {
        showNotification('رقم البطاقة غير صحيح');
        return;
    }
    
    if (!/^\d{2}\/\d{2}$/.test(cardExpiry)) {
        showNotification('تاريخ الانتهاء غير صحيح (استخدم MM/YY)');
        return;
    }
    
    if (!/^\d{3,4}$/.test(cardCvc)) {
        showNotification('رمز الأمان غير صحيح');
        return;
    }
    
    // Simulate payment processing
    showNotification('جاري معالجة طلب الاشتراك...', true);
    
    setTimeout(() => {
        // Update user to PRO
        currentUser.isPro = true;
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        
        // Update all users data
        const users = JSON.parse(localStorage.getItem('users')) || [];
        const userIndex = users.findIndex(u => u.email === currentUser.email);
        if (userIndex !== -1) {
            users[userIndex].isPro = true;
            localStorage.setItem('users', JSON.stringify(users));
        }
        
        // Update UI
        checkAuthState();
        showNotification('تم ترقية حسابك إلى PRO بنجاح!', true);
        closeAuthModal();
        
        // Reload wallpapers to show premium content
        renderWallpapers(wallpapers);
    }, 2000);
}

// Handle logout
function handleLogout() {
    // Clear user data
    localStorage.removeItem('currentUser');
    currentUser = null;
    
    // Update UI
    checkAuthState();
    showNotification('تم تسجيل الخروج بنجاح');
    
    // Close sidebar if open
    if (isSidebarOpen) {
        toggleSidebar();
    }
    
    // Reload wallpapers to hide premium content
    renderWallpapers(wallpapers);
}

// Setup event listeners
function setupEventListeners() {
    // Search input
    searchInput.addEventListener('input', (e) => {
        searchWallpapers(e.target.value);
    });

    // Modal close
    modalClose.addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });

    // Download button in modal
    downloadBtn.addEventListener('click', () => {
        if (currentWallpaper) downloadWallpaper(currentWallpaper.id);
    });

    // Set wallpaper button in modal
    setWallpaperBtn.addEventListener('click', () => {
        if (currentWallpaper) setAsWallpaper(currentWallpaper.id);
    });

    // Scroll to top button
    scrollTopBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // Show/hide scroll to top button
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            scrollTopBtn.classList.add('visible');
        } else {
            scrollTopBtn.classList.remove('visible');
        }
    });

    // Dark mode toggle
    darkModeToggle.addEventListener('click', toggleDarkMode);

    // Search toggle
    searchToggle.addEventListener('click', toggleSearch);

    // Close search when clicking outside
    document.addEventListener('click', (e) => {
        if (isSearchVisible && 
            !searchContainer.contains(e.target) && 
            e.target !== searchToggle) {
            toggleSearch();
        }
    });

    // Menu button for sidebar
    menuBtn.addEventListener('click', toggleSidebar);
    sidebarClose.addEventListener('click', toggleSidebar);
    sidebarOverlay.addEventListener('click', toggleSidebar);

    // Login button in sidebar
    loginBtn.addEventListener('click', (e) => {
        e.preventDefault();
        toggleSidebar();
        openAuthModal('login');
    });

    // PRO button in sidebar
    proBtnSidebar.addEventListener('click', (e) => {
        e.preventDefault();
        toggleSidebar();
        openProSubscription();
    });

    // Category buttons
    categoryBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            setActiveCategory(btn.dataset.category);
        });
    });
    
    // Auth modal close
    authClose.addEventListener('click', closeAuthModal);
    authModal.addEventListener('click', (e) => {
        if (e.target === authModal) closeAuthModal();
    });
    
    // Login form submit
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        handleLogin(email, password);
    });
    
    // Register form submit
    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('registerName').value;
        const email = document.getElementById('registerEmail').value;
        const password = document.getElementById('registerPassword').value;
        const confirmPassword = document.getElementById('registerConfirmPassword').value;
        handleRegister(name, email, password, confirmPassword);
    });
    
    // Show register form
    showRegister.addEventListener('click', (e) => {
        e.preventDefault();
        currentView = 'register';
        updateAuthView();
    });
    
    // Show login form
    showLogin.addEventListener('click', (e) => {
        e.preventDefault();
        currentView = 'login';
        updateAuthView();
    });
    
    // Login/Register tabs
    loginTab.addEventListener('click', (e) => {
        e.preventDefault();
        currentView = 'login';
        updateAuthView();
    });
    
    registerTab.addEventListener('click', (e) => {
        e.preventDefault();
        currentView = 'register';
        updateAuthView();
    });
    
    // Subscribe button
    subscribeBtn.addEventListener('click', (e) => {
        e.preventDefault();
        handleSubscribe();
    });
    
    // Payment form submit
    paymentForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const cardNumber = document.getElementById('cardNumber').value;
        const cardExpiry = document.getElementById('cardExpiry').value;
        const cardCvc = document.getElementById('cardCvc').value;
        const cardName = document.getElementById('cardName').value;
        handlePayment(cardNumber, cardExpiry, cardCvc, cardName);
    });
    
    // Logout button
    logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        handleLogout();
    });
}

// Initialize the app
init();

// Make functions available globally for HTML onclick attributes
window.downloadWallpaper = downloadWallpaper;
window.setAsWallpaper = setAsWallpaper;
window.toggleLike = toggleLike;